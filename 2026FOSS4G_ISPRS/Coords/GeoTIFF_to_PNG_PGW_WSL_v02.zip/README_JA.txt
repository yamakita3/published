GeoTIFF -> PNG / PGW / PRJ 一括変換（Windows CMD + WSL）
=======================================================

1. 同梱ファイル
----------------
run_tif2png.bat : Windowsでダブルクリック / フォルダをD&Dする入口
 tif2png.py     : WSLのPythonで実行する変換本体
 README_JA.txt  : この説明書

BATとPythonは必ず同じフォルダに置いてください。
ZIP内から直接実行せず、先に通常のWindowsフォルダへ展開します。
既存の同名BAT/Pythonと混同しないよう、新しい専用フォルダへの展開を推奨します。

2. 普段の使い方
----------------
(1) run_tif2png.bat と tif2png.py を同じフォルダに配置。
(2) TIFFが入ったフォルダを、run_tif2png.bat のアイコンへD&D。
(3) 入力フォルダの中に output_png が自動作成されます。
(4) 画面で進捗を確認。終了時もエラー時もキー入力まで画面を保持します。

出力例:
  入力フォルダ/
    image01.tif
    image02.TIFF
    output_png/
      image01.png
      image01.pgw
      image01.prj
      image02.png
      image02.pgw
      image02.prj
      conversion.log

・入力GeoTIFFは変更・削除しません。
・既存の同名出力は上書きします。残しておきたい結果は事前に退避してください。
・PNGは8bit RGBA画像です。元の数値精度を維持する解析用ファイルではありません。
・画素数、画素位置、CRSは変えません。再投影、リサイズ、北向きへの回転はしません。
・PGWには位置と画素サイズ等、PRJには座標参照系のWKTを保存します。
  PRJを自動認識しないGISでは、元GeoTIFFと同じCRSを手動で指定してください。
・対象拡張子は.tifと.tiff。大文字/小文字を区別しません。
・既定は入力フォルダ直下のみ。複数フォルダの同時D&Dには対応しません。

CMDからも実行できます（パスは実際のものに置き換えてください）:
  "C:\tools\geotiff_png\run_tif2png.bat" "C:\data\GeoTIFF"

3. 初回だけ：WSLとPython環境を準備
----------------------------------
すでにWSLの実行用Pythonにnumpy / rasterio / Pillowがある場合は不要です。
BATは依存ライブラリを自動インストールせず、不足時に停止します。

まずWindowsのCMDで以下を確認します:
  wsl --list --verbose
  wsl --exec python3 --version

WSLが未導入・未初期化の場合は、先にWSLとLinuxディストリビューションを導入し、
初回起動時のLinuxユーザー設定を完了してください。
既定以外のディストリビューションを使う場合は、BATのWSL_DISTROに名前を設定します。

以下はUbuntu / Debian系WSLのターミナルで実行する初回設定例です。
別のディストリビューションではOSのパッケージ管理方法に合わせてください。

  sudo apt update
  sudo apt install -y python3-venv python3-pip
  python3 -m venv "$HOME/.venvs/geotiff_png"
  "$HOME/.venvs/geotiff_png/bin/python" -m pip install --upgrade pip
  "$HOME/.venvs/geotiff_png/bin/python" -m pip install numpy rasterio Pillow
  "$HOME/.venvs/geotiff_png/bin/python" -c "import numpy, rasterio, PIL; print('OK')"
  echo "$HOME/.venvs/geotiff_png/bin/python"

最後に表示された絶対パスを、BAT内のWSL_PYTHONに設定します。
例（taro部分は実際のLinuxユーザー名に置き換え）:
  set "WSL_PYTHON=/home/taro/.venvs/geotiff_png/bin/python"

重要:
・Windows側のpipではなく、WSL内の実行用Pythonにインストールします。
・apt/pipによる導入はネットワークと権限が必要です。
・pipでwheelが得られないCPU/環境では、GDAL等の追加準備が必要になる場合があります。
・既存のconda/venvがある場合、その環境のPythonの絶対パスを指定しても構いません。
・BATはWSLを非対話起動するため、.bashrcのconda activate等には依存しません。

4. ストレッチ・RGBの指定
------------------------
BATをテキストエディタで開き、冒頭の設定のみ変更してください。
保存形式はUTF-8（BOMなし推奨）、改行はWindows CRLFです。

既定（添付スクリプトと同じ固定範囲）:
  set "GTP_MIN=0.02"
  set "GTP_MAX=0.25"
  set "GTP_BANDS=1 2 3"

RGBごとに別の範囲を指定する例:
  set "GTP_MIN=0.02 0.03 0.01"
  set "GTP_MAX=0.25 0.28 0.20"

R/G/Bへ割り当てるバンドを変える例:
  set "GTP_BANDS=3 2 1"

ストレッチ式:
  PNG値 = uint8(255 * clip((入力値 - 下限) / (上限 - 下限), 0, 1))
下限以下は0、上限以上は255に飽和します。
各バンドとも上限 > 下限が必要です。
パーセンタイル自動調整、ガンマ補正、単バンドのカラーマップ化ではありません。
同じ設定を全ファイルへ適用します。

注意:
ストレッチ値は、TIFF内に実際に格納されている数値の単位で指定してください。
例として反射率0.02～0.25を10000倍した整数で格納している場合は200～2500です。
TIFFのscale/offsetメタデータは自動適用しません。非既定値なら警告を表示します。
この例が全GeoTIFFに当てはまるわけではありません。

5. サブフォルダも対象にする場合
--------------------------------
BATで以下を変更します:
  set "GTP_RECURSIVE=1"

サブフォルダの相対構造を output_png の下にも再現します。
例: 入力/subA/a.tif -> 入力/output_png/subA/a.png
出力フォルダ自体は探索対象から除外します。
直下だけに戻す場合は0にします。

6. エラー時の挙動
------------------
・最初のエラーで停止し、以後のファイルは処理しません。
・それまでに正常出力されたファイルは残します。
・対象ファイル名、例外の詳細（トレースバック）、ログの場所を表示します。
・通常の処理エラーは output_png/conversion.log にも記録します。
・ログは再実行時も追記します。
・WSL起動前の失敗、Pythonが見つからない、出力先を作成できない等は、
  ログが作れないため画面表示で確認してください。
・画面はpauseで保持します。ただしウィンドウの×やOS側の強制終了は防げません。

安全のため停止する例:
・入力フォルダがない / 対象TIFFがない
・指定RGBバンドが存在しない（既定は3バンド以上が必要）
・CRSがない / GCP・RPCだけで通常のアフィン格子になっていない
・同一フォルダにa.tifとa.tiffがあるなど、出力名が重複する
・画像が破損している / メモリ不足 / 保存先への書き込みに失敗

7. 位置情報・NoData・大容量画像について
----------------------------------------
PGWの順序はA,D,B,E,C,Fです。C/Fは左上画素の中心を示し、
回転項も含めて中心座標を計算します。
NoData、内部マスク、Rasterioが認識するアルファを使用し、
RGBのいずれかが無効、またはNaN/Infの画素を透明にします。
値が0という理由だけで透明にはしません（入力のNoData指定等があれば別です）。

512行ずつ読み込みますが、出力用RGBA配列は画像全体を保持します。
配列だけで4 x 幅 x 高さバイト。PNG生成時や読み込み時には追加メモリが必要です。
巨大な画像は十分なRAMを用意し、必要なら事前にタイル分割してください。

このBATはWindowsの通常のローカルドライブ上のフォルダを主対象としています。
日本語・空白・丸括弧を含むパスはWSLENVのパス変換で渡す設計です。
ネットワーク共有、WSL自身のUNCパス、特殊なファイルシステムは実機確認が必要です。
OneDrive等の未ダウンロードファイルは先にローカルへ取得してください。

8. WSLからPythonだけを直接実行する場合
---------------------------------------
パスは例です。実際の配置に置き換えます。

  /home/taro/.venvs/geotiff_png/bin/python /mnt/c/tools/geotiff_png/tif2png.py "/mnt/c/data/GeoTIFF" --min 0.02 --max 0.25 --bands 1 2 3

出力先を別指定する例:
  python3 tif2png.py "/mnt/c/data/GeoTIFF" "/mnt/d/result" --min 0.02 --max 0.25

Python単体の実行は終了後にpauseしません。画面保持はBAT側の機能です。

9. 作成時の検証範囲
--------------------
Pythonの構文チェックと、模擬Rasterio入力による16項目のテストを実施しました。
対象: ストレッチ、透過、512行境界、回転PGW、拡張子、再帰探索、
出力名重複、CRS欠落、引数解析、途中エラーでの停止、ログ等。

作成環境にはRasterioおよびWindows/WSLがないため、実際のGeoTIFFを使った
Rasterio実行と、WindowsでのD&D～WSL起動の通し試験は未実施です。
最初に小さなGeoTIFFを1～2枚入れたテストフォルダで実行し、
元GeoTIFFとPNGをGIS上で重ねて位置と表示色をご確認ください。
