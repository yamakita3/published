#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GeoTIFFを固定範囲でストレッチし、PNG / PGW / PRJに変換する。

・元の画素数、アフィン変換、CRSは変更しない（再投影・リサイズなし）。
・既定はバンド1/2/3をR/G/Bとして使用する。
・エラーは握りつぶさず、そのファイルで停止する。
"""
from __future__ import annotations

import argparse
import logging
import math
import os
from pathlib import Path
import sys
import tempfile

LOG = logging.getLogger("geotiff_png")


def load_dependencies():
    """起動時に依存関係を確認。自動インストールは行わない。"""
    global np, rasterio, Image, Window
    try:
        import numpy as np
        import rasterio
        from PIL import Image
        from rasterio.windows import Window
    except ImportError as exc:
        raise RuntimeError(
            "WSLの実行用Pythonに必要なライブラリがありません。\n"
            "READMEの初回設定に従い、numpy / rasterio / Pillowを\n"
            "インストールし、BATのWSL_PYTHONを設定してください。\n"
            f"不足の詳細: {exc}"
        ) from exc


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description="フォルダ内のGeoTIFFをPNG + PGW + PRJに変換"
    )
    parser.add_argument("input_dir", type=Path, help="入力フォルダ")
    parser.add_argument("output_dir", type=Path, nargs="?", default=None,
                        help="省略時: 入力フォルダ/output_png")
    parser.add_argument("--min", dest="vmin", nargs="+", type=float,
                        default=[0.02], help="下限: 共通1値またはR G Bの3値")
    parser.add_argument("--max", dest="vmax", nargs="+", type=float,
                        default=[0.25], help="上限: 共通1値またはR G Bの3値")
    parser.add_argument("--bands", nargs=3, type=int, default=[1, 2, 3],
                        metavar=("R", "G", "B"), help="R/G/Bに使うバンド番号（1始まり）")
    parser.add_argument("--recursive", action="store_true",
                        help="サブフォルダも処理（相対フォルダ構造を維持）")
    return parser.parse_args(argv)


def expand_limits(values, label):
    """共通の1値をRGBの3値へ展開し、不正値を検出する。"""
    if len(values) not in (1, 3):
        raise ValueError(f"{label}は1個または3個の数値を指定してください。")
    result = list(values) * 3 if len(values) == 1 else list(values)
    if not all(math.isfinite(value) for value in result):
        raise ValueError(f"{label}にNaNや無限大は指定できません。")
    return result


def configure_logging(log_path):
    """画面とUTF-8ログの両方へ出力。再実行時はログ末尾に追記する。"""
    LOG.setLevel(logging.INFO)
    for handler in LOG.handlers[:]:
        handler.close()
        LOG.removeHandler(handler)
    formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s",
                                  datefmt="%Y-%m-%d %H:%M:%S")
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(formatter)
    LOG.addHandler(console)
    file_handler = logging.FileHandler(log_path, mode="a", encoding="utf-8")
    file_handler.setFormatter(formatter)
    LOG.addHandler(file_handler)
    LOG.propagate = False


def find_inputs(input_dir, output_dir, recursive):
    """拡張子の大小を区別せず.tif/.tiffを取得。出力先配下は除く。"""
    candidates = input_dir.rglob("*") if recursive else input_dir.iterdir()
    files = []
    for path in candidates:
        if not path.is_file() or path.suffix.lower() not in (".tif", ".tiff"):
            continue
        if output_dir == path.parent.resolve() or output_dir in path.resolve().parents:
            continue
        files.append(path)
    return sorted(files, key=lambda p: str(p.relative_to(input_dir)).casefold())


def check_output_collisions(files, input_dir):
    """例: a.tifとa.tiffは同じa.pngになるため、書き込み前に停止する。"""
    seen = {}
    for path in files:
        key = str(path.relative_to(input_dir).with_suffix(".png")).casefold()
        if key in seen:
            raise ValueError(
                f"出力ファイル名が重複します: {seen[key]} / {path}\n"
                "片方の入力ファイル名を変更してください。"
            )
        seen[key] = path


def world_file_text(transform):
    """PGWの順序はA,D,B,E,C,F。C/Fは左上画素の中心座標。

    回転のあるGeoTIFFにも対応するため、中心座標計算には
    a/eだけでなくb/d（回転・せん断の項）も含める。
    """
    center_x, center_y = transform * (0.5, 0.5)
    values = (transform.a, transform.d, transform.b, transform.e,
              center_x, center_y)
    return "\n".join(f"{float(value):.17g}" for value in values) + "\n"


def convert_one(input_tif, destination, vmin, vmax, bands):
    """1ファイルを変換。最終名に直接書かず、一時フォルダで作成する。"""
    destination.mkdir(parents=True, exist_ok=True)
    out_png = destination / (input_tif.stem + ".png")
    out_pgw = out_png.with_suffix(".pgw")
    out_prj = out_png.with_suffix(".prj")
    if any(p.exists() for p in (out_png, out_pgw, out_prj)):
        LOG.warning("既存の同名出力を上書きします: %s", out_png)

    with rasterio.open(input_tif) as src:
        if any(band < 1 or band > src.count for band in bands):
            raise ValueError(
                f"バンド指定 {bands} は入力のバンド数 {src.count} に対応していません。\n"
                "BATのGTP_BANDSを確認してください。RGB画像の既定値は1 2 3です。"
            )
        if src.crs is None:
            raise ValueError(
                "入力にCRS（座標参照系）がありません。誤った位置情報の出力を\n"
                "避けるため停止します。入力GeoTIFFのCRS設定を確認してください。"
            )
        # PGWはアフィン変換を記録する。GCP/RPCだけの位置情報は変換できない。
        if src.transform.is_identity:
            gcps, _ = src.gcps
            if gcps or src.rpcs:
                raise ValueError(
                    "GCP/RPCのみの位置情報はPGWに直接保存できません。\n"
                    "先にGIS等でオルソ化・アフィン格子への変換を行ってください。"
                )
            LOG.warning("アフィン変換が単位行列です。入力の位置情報を確認してください。")

        width, height = src.width, src.height
        LOG.info("サイズ=%s x %s px / CRS=%s / RGBバンド=%s",
                 width, height, src.crs, bands)
        LOG.info("出力RGBA配列だけで約 %.1f MiB のメモリを使用します。",
                 width * height * 4 / (1024 * 1024))
        if any(src.scales[b - 1] != 1 or src.offsets[b - 1] != 0 for b in bands):
            LOG.warning("入力にscale/offsetがありますが、自動適用しません。"
                        "ストレッチ値は格納された画素値の単位で指定してください。")

        # 巨大な3バンドfloat画像を丸ごと保持しないよう、512行ずつ読み込む。
        # 最終PNG作成用のRGBA配列は全画素分を保持するため、RAMは必要。
        rgba = np.empty((height, width, 4), dtype=np.uint8)
        low = np.asarray(vmin, dtype=np.float64)[:, None, None]
        high = np.asarray(vmax, dtype=np.float64)[:, None, None]
        for row in range(0, height, 512):
            rows = min(512, height - row)
            window = Window(0, row, width, rows)
            data = src.read(indexes=bands, window=window, out_dtype="float64")
            masks = src.read_masks(indexes=bands, window=window)
            # NoData/内部マスク/認識されたアルファを考慮する。
            # RGBのいずれかが無効、またはNaN/Infならその画素を透明にする。
            alpha = masks.min(axis=0).copy()
            alpha[~np.isfinite(data).all(axis=0)] = 0
            valid = alpha > 0
            data = np.where(valid[None, :, :], data, low)
            scaled = (data - low) / (high - low)
            scaled = (np.clip(scaled, 0.0, 1.0) * 255.0).astype(np.uint8)
            rgba[row:row + rows, :, :3] = scaled.transpose(1, 2, 0)
            rgba[row:row + rows, :, 3] = alpha

        if not rgba[:, :, 3].any():
            LOG.warning("全画素が無効です。出力PNGは全面透明になります。")
        pgw_text = world_file_text(src.transform)
        prj_text = src.crs.to_wkt()
        LOG.info("PNGを書き込み中: %s", out_png)
        # 変換途中の失敗で不完全なPNGを最終名に残さない。
        # 3ファイルまとめての置換は原子的ではないため、置換時のI/O障害には注意。
        with tempfile.TemporaryDirectory(prefix=".tif2png_", dir=destination) as tmp:
            tmpdir = Path(tmp)
            image = Image.fromarray(rgba)
            try:
                image.save(tmpdir / "image.png", format="PNG")
            finally:
                image.close()
            (tmpdir / "image.pgw").write_text(pgw_text, encoding="ascii")
            (tmpdir / "image.prj").write_text(prj_text, encoding="utf-8")
            os.replace(tmpdir / "image.png", out_png)
            os.replace(tmpdir / "image.pgw", out_pgw)
            os.replace(tmpdir / "image.prj", out_prj)
    LOG.info("OK: %s", out_png)


def main(argv=None):
    args = parse_args(argv)
    log_path = None
    current_file = None
    succeeded = 0
    try:
        input_dir = args.input_dir.expanduser().resolve()
        if not input_dir.is_dir():
            raise NotADirectoryError(f"入力フォルダが見つかりません: {input_dir}")
        output_dir = (args.output_dir.expanduser().resolve() if args.output_dir
                      else input_dir / "output_png")
        if output_dir == input_dir:
            raise ValueError("出力先に入力フォルダそのものは指定できません。")
        output_dir.mkdir(parents=True, exist_ok=True)
        log_path = output_dir / "conversion.log"
        configure_logging(log_path)
        LOG.info("========== GeoTIFF -> PNG / PGW / PRJ ==========")
        LOG.info("実行Python: %s", sys.executable)
        LOG.info("入力: %s", input_dir)
        LOG.info("出力: %s", output_dir)
        vmin = expand_limits(args.vmin, "--min")
        vmax = expand_limits(args.vmax, "--max")
        if any(hi <= lo for lo, hi in zip(vmin, vmax)):
            raise ValueError("各バンドのストレッチ上限は下限より大きくしてください。")
        LOG.info("下限(R,G,B): %s / 上限(R,G,B): %s", vmin, vmax)
        LOG.info("サブフォルダ: %s", "対象" if args.recursive else "対象外")
        load_dependencies()
        files = find_inputs(input_dir, output_dir, args.recursive)
        if not files:
            raise FileNotFoundError("対象の.tif / .tiffファイルが見つかりません。")
        check_output_collisions(files, input_dir)
        LOG.info("対象: %sファイル", len(files))
        for number, path in enumerate(files, start=1):
            current_file = path
            LOG.info("[%s/%s] 処理開始: %s", number, len(files), path)
            destination = output_dir / path.parent.relative_to(input_dir)
            convert_one(path, destination, vmin, vmax, args.bands)
            succeeded += 1
        LOG.info("完了: %s / %sファイル", succeeded, len(files))
        LOG.info("出力先: %s", output_dir)
        return 0
    except Exception:
        # ここで一括捕捉し、トレースバックを画面とログへ出す。
        # 例外を無視して次のファイルに進むことはしない。
        if not LOG.handlers:
            logging.basicConfig(level=logging.INFO,
                                format="%(levelname)s: %(message)s", stream=sys.stdout)
        LOG.exception("変換を停止しました。完了済み: %sファイル / 対象: %s",
                      succeeded, current_file if current_file else "開始前")
        if log_path and log_path.exists():
            LOG.error("ログ: %s", log_path)
        return 1


if __name__ == "__main__":
    # BAT経由でも日本語をUTF-8で出力。端末側もchcp 65001を使用する。
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")
    sys.exit(main())
