@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul

REM ================================================================
REM GeoTIFF 一括変換ランチャー（Windows CMD -> WSL -> Python）
REM このBATと tif2png.py を同じフォルダに置き、入力フォルダを
REM このBATへドラッグ＆ドロップしてください。
REM 遅延環境変数展開は無効にし、パス中の ! を壊さないようにします。
REM ================================================================

REM -------------------- 変更する設定 ------------------------------
REM WSLディストリビューション名。空欄なら既定のWSLを使います。
REM 例: set "WSL_DISTRO=Ubuntu"
set "WSL_DISTRO="

REM WSL内で使うPython。Windows側のPythonではありません。
REM 仮想環境を使う場合は /home/ユーザー名/.../bin/python に変更します。
set "WSL_PYTHON=python3"

REM ストレッチ下限・上限。添付スクリプトと同じ既定値です。
REM 共通値: 0.02 / 0.25。RGB別指定の例: 0.02 0.03 0.01
REM 実際の格納値が0～10000なら、対応する例は200 / 2500です。
set "GTP_MIN=0.02"
set "GTP_MAX=0.25"

REM R G B に使うバンド番号（1始まり）。既定は1 2 3です。
set "GTP_BANDS=1 2 3"

REM 0: 入力フォルダ直下のみ / 1: サブフォルダも含める
set "GTP_RECURSIVE=0"
REM -------------------- 設定ここまで ------------------------------

REM 引数なし・複数フォルダ指定は、誤処理せず画面で案内します。
if "%~1"=="" goto :NO_INPUT
if not "%~2"=="" goto :TOO_MANY
set "GTP_INPUT=%~f1"
set "GTP_SCRIPT=%~dp0tif2png.py"

if not exist "%GTP_INPUT%\." goto :NOT_FOLDER
if not exist "%GTP_SCRIPT%" goto :NO_SCRIPT
where wsl.exe >nul 2>&1
if errorlevel 1 goto :NO_WSL

REM WindowsパスはWSLENVの/pでWSLのパスへ変換します。
REM パスをbashのコマンド文字列に埋め込まないため、空白や日本語、
REM 丸括弧などを含む通常のローカルフォルダにも対応します。
REM 既存のWSLENVはこのBAT内だけで引き継ぎ、永続設定は変更しません。
set "PYTHONUTF8=1"
if defined WSLENV goto :APPEND_ENV
set "WSLENV=GTP_INPUT/p:GTP_SCRIPT/p:GTP_MIN:GTP_MAX:GTP_BANDS:GTP_RECURSIVE:PYTHONUTF8"
goto :RUN
:APPEND_ENV
set "WSLENV=%WSLENV%:GTP_INPUT/p:GTP_SCRIPT/p:GTP_MIN:GTP_MAX:GTP_BANDS:GTP_RECURSIVE:PYTHONUTF8"

:RUN
echo ================================================================
echo GeoTIFF to PNG + PGW + PRJ
echo ================================================================
echo 入力: "%GTP_INPUT%"
echo 出力: 入力フォルダ内の output_png
echo 下限: %GTP_MIN%
echo 上限: %GTP_MAX%
echo RGB : %GTP_BANDS%
echo 再帰: %GTP_RECURSIVE%  [0=直下のみ / 1=サブフォルダも対象]
echo 同名の出力ファイルがある場合は上書きします。
echo ================================================================
echo.

REM Python標準ライブラリのrunpyで実行します。
REM 引数を環境変数から読むため、Windows/Linux間のパスの再引用を避けます。
REM -uは出力バッファを抑制し、進捗・エラーをその場で表示する指定です。
if defined WSL_DISTRO goto :RUN_NAMED
wsl.exe --exec "%WSL_PYTHON%" -u -c "import os,runpy,sys; e=os.environ; sys.argv=[e['GTP_SCRIPT'],e['GTP_INPUT'],'--min']+e['GTP_MIN'].split()+['--max']+e['GTP_MAX'].split()+['--bands']+e['GTP_BANDS'].split()+(['--recursive'] if e['GTP_RECURSIVE']=='1' else []); runpy.run_path(e['GTP_SCRIPT'],run_name='__main__')"
goto :AFTER_RUN

:RUN_NAMED
wsl.exe --distribution "%WSL_DISTRO%" --exec "%WSL_PYTHON%" -u -c "import os,runpy,sys; e=os.environ; sys.argv=[e['GTP_SCRIPT'],e['GTP_INPUT'],'--min']+e['GTP_MIN'].split()+['--max']+e['GTP_MAX'].split()+['--bands']+e['GTP_BANDS'].split()+(['--recursive'] if e['GTP_RECURSIVE']=='1' else []); runpy.run_path(e['GTP_SCRIPT'],run_name='__main__')"

:AFTER_RUN
REM gotoやechoで終了コードを失わないよう、直後に保存します。
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" goto :CONVERSION_ERROR
echo.
echo [完了] すべての処理が終了しました。
echo 出力先は入力フォルダ内の output_png です。
echo ログは output_png 内の conversion.log です。
echo.
pause
exit /b 0

:NO_INPUT
echo [ERROR] 変換したいフォルダを、このBATへドラッグ＆ドロップしてください。
echo CMDからの実行例: run_tif2png.bat "C:\data\GeoTIFF"
goto :FAIL
:TOO_MANY
echo [ERROR] 一度に指定できる入力フォルダは1つです。
goto :FAIL
:NOT_FOLDER
echo [ERROR] 入力フォルダが見つかりません: "%GTP_INPUT%"
goto :FAIL
:NO_SCRIPT
echo [ERROR] このBATと同じフォルダに tif2png.py がありません。
echo 確認先: "%GTP_SCRIPT%"
goto :FAIL
:NO_WSL
echo [ERROR] wsl.exe が見つかりません。WSLをインストールしてください。
goto :FAIL
:CONVERSION_ERROR
echo.
echo [ERROR] エラーが発生したため処理を停止しました。終了コード: %RESULT%
echo 上に表示されたエラー内容をご確認ください。
echo ログを作成できた場合は output_png 内の conversion.log に詳細があります。
echo Pythonがない場合やWSLが起動できない場合はREADMEを確認してください。
echo この画面はキーを押すまで閉じません。
echo.
pause
exit /b %RESULT%
:FAIL
echo.
pause
exit /b 1
